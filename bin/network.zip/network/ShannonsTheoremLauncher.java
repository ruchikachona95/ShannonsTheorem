package network;

/***
 * this class demonstrates the model view controller
 * @author Ruchika Chona
 * @version   1.0.0 Date 2015/11/04
 *
 */
public class ShannonsTheoremLauncher {

	public static void main(String[] args) {
		ShannonsTheorem app = new ShannonsTheorem();
		app.initGUI();

	}

}
